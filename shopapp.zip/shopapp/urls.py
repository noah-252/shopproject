from django.urls import path
from . import views

from django.conf import settings
from django.conf.urls.static import static

app_name = 'shopapp'
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),

    #path(
    #     'Shop-detail/<int:pk>/',
    #     views.Shop_detail,
    #     name = 'Shop_detail',
    #     ),
    path('post/', views.CreateShopView.as_view(), name='post'),
    path('shop/<category>', views.CategoryView.as_view(), name='shop_category'),
    path('contact',views.ContactView.as_view(),name='contact'),
    path('toggle_like/<int:pk>/', views.toggle_like, name='toggle_like'),
    path('purchase/<int:pk>/', views.PurchaseView.as_view(), name='shop_purchase'),
    path('buy/', views.CreateShopView.as_view(), name='buy'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

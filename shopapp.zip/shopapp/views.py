from django.forms import BaseModelForm

from django.http import Http404, HttpResponse, HttpResponseNotFound

from django.shortcuts import render,get_object_or_404

from .models import Category, ShopPost

from django.views.generic import TemplateView, ListView, CreateView, FormView

from django.urls import reverse_lazy, reverse

from .forms import ShopPostForm, ContactForm

from  django.utils.decorators import method_decorator

from django.contrib.auth.decorators import login_required

from django.contrib import messages

from django.core.mail import EmailMessage

from django.shortcuts import render, redirect

from .models import Product, Like

def buy_view(request):
    if request.method == "POST":
        form = ShopPostForm(request.POST, request.FILES)
        if form.is_valid():
            # 画像ファイルの処理
            image = form.cleaned_data['image1']
            # 保存処理などを実行




def your_view(request):
    if request.method == 'POST':
        form = ShopPostForm(request.POST, request.FILES)  # request.FILESを渡して画像を受け取る
        if form.is_valid():
            form.save()  # フォームを保存して新しい商品を作成
            return redirect('success_url')  # 送信後のリダイレクト先
    else:
        form = ShopPostForm()
    
    return render(request, 'your_template.html', {'form': form})

class CreateShopView(CreateView):
    form_class = ShopPostForm
    template_name = 'buy.html'
    success_url = reverse_lazy('shopapp:index')

    def form_valid(self, form):
        postdata = form.save(commit=False)
        postdata.user = self.request.user
        postdata.save()
        return super().form_valid(form)

@login_required
def liked_products(request):
    products = request.user.liked_products.all()
    return render(request, 'liked_products.html', {'products': products})


@login_required
def toggle_like(request, product_id):
    if not product_id:
        raise Http404("Product ID is missing")  # product_idが空ならエラーを発生させる

    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        raise Http404("Product not found")
    user = request.user
    
    # すでにいいねしているか確認
    like, created = Like.objects.get_or_create(user=user, product=product)
    
    if not created:
        # いいねを取り消す（既に存在していれば削除）
        like.delete()
    
    return redirect('index', product_id=product_id)

class IndexView(ListView):
    template_name = 'index.html'
    queryset = ShopPost.objects.order_by('-posted_at')
    paginate_by=9


    
class CategoryView(ListView):
    template_name='index.html'
    paginate_by = 9
    def get_queryset(self):
        category_name = self.kwargs['category']
        try:
            category = Category.objects.filter(title=category_name).get()
        except:
            raise Http404()

        categories = ShopPost.objects.filter(category=category).order_by('-posted_at')
        return categories

class ContactView(FormView):
    template_name = 'contact.html'
    form_class = ContactForm
    success_url = reverse_lazy('shopapp:contact')

    def form_valid(self,form):
        name = form.cleaned_data['name']
        email = form.cleaned_data['email']
        title = form.cleaned_data['title']
        message = form.cleaned_data['message']
        subject = 'お問い合わせ: {}'.format(title)

        message = \
            '送信者名: {0}\nメールアドレス: {1}\n タイトル:{2}\n メッセージ:\n{3}' \
            .format(name, email, title, message)
        
        from_email = 'mit2471571@gmail.com'
        to_list = ['mit2471571@gmail.com']
        message = EmailMessage(subject = subject, body = message, from_email = from_email, to = to_list,)
        message.send()
        messages.success(self.request, 'お問い合わせは正常に送信されました。')
        return super().form_valid(form)
        
@method_decorator(login_required, name='dispatch')
class PurchaseView(TemplateView):
   template_name = 'purchase.html'
   def post(self, request, *args, **kwargs):
       # 商品の取得
       ShopPost_id = self.kwargs.get('pk')
       ShopPost = get_object_or_404(ShopPost, pk=ShopPost_id)
       # 在庫確認と購入処理
       if ShopPost.stock > 0:
           ShopPost.stock -= 1
           ShopPost.save()
        #   ↑二つをショップポスト(コンテンツ)の削除とのちに入れ替え
           # 購入成功メッセージ
           messages.success(request, f"{object.title} を購入しました！")
       else:
           # 在庫不足エラー
           messages.error(request, f"{object.title} の在庫がありません。")
       return redirect('shopapp:index')  # 必要に応じてリダイレクト先を変更